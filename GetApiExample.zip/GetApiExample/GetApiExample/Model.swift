//
//  Model.swift
//  GetApiExample
//
//  Created by syed fazal abbas on 20/05/23.
//

import Foundation
struct HeroStats : Decodable{
    
    let name : String
    let localized_name : String
    let primary_attr : String
    let attack_type : String
     let img : String
 }
